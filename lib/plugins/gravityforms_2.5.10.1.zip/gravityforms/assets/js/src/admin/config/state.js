export default {
	desktopInitialized: false,
	isDesktop: false,
	isMobile: false,
	mobileInitialized: false,
	vHeight: 0,
	vWidth: 0,
};
